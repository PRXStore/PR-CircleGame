var randomLetter;
CloseGame();
$(document).ready(function () {
  CloseGame();
});

window.addEventListener('message', (event) => {
  switch (event.data.action) {
    case "open":
      CloseGame();
      StartCircleGame();
      break;
    default:
      break;
  }
});

// StartCircleGame();

function StartCircleGame() {
  $(".container").show();
  $('.container-circle').animate({
    width: '250px',
    height: '250px'
  }, 2500, function () {
    CloseGame();
  });

  $('.letter-random').each(function () {
    var randomCharCode = Math.floor(Math.random() * 26) + 65;
    randomLetter = String.fromCharCode(randomCharCode);
    $(this).text(randomLetter);
  });

  $(document).keypress(function (event) {
    if (randomLetter && event.key.toUpperCase() == randomLetter) {
    
      if ($(".container-circle").length > 0) {
        var circleWidth = $(".container-circle").width();
        var circleHeight = $(".container-circle").height();


        if (circleWidth >= 340 && circleWidth <= 470 && circleHeight >= 340 && circleHeight <= 470) {
          console.log("Success");
          CloseGameAndPostResult(true);
        } else {
          console.log("False");
          CloseGameAndPostResult(false);
        }
      } else {
       
        console.log(".container-circle element not found");
      }

    }
  });
}

function CloseGameAndPostResult(success) {
  CloseGame();
  $.post(`https://PR-circlegame/result`, JSON.stringify({ success: success }));
  setTimeout(() => {
  window.location.reload(); 
  }, 500);
}

function CloseGame() {
  $(".container").hide();
  $('.container-circle').height('900px');
  $('.container-circle').width('900px');
}


