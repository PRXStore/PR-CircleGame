local QBCore = exports['qb-core']:GetCoreObject()

local successCb
local failCb
local resultReceived = false

RegisterNUICallback('result', function(data, cb)
    SetNuiFocus(false, false)
    resultReceived = true
    if data.success then
        if successCb then
            successCb()
        end
    else
        if failCb then
            failCb()
        end
    end
    cb('ok')
end)

RegisterNUICallback("close", function()
    SetNuiFocus(false, false)
end)

exports('minigame', function(success, fail)
    resultReceived = false
    successCb = success
    failCb = fail
    SetNuiFocus(true, false)
    SendNUIMessage({
        action = "open",
    })
end)




RegisterCommand("prxcirclegame", function()
    exports["PR-circlegame"]:minigame(function()
        QBCore.Functions.Notify("Success", "primary", 5000)
    end, function()
        QBCore.Functions.Notify("False", "error", 5000)
    end)
end)
